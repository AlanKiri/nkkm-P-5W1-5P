from storage import Storage
import os 

class UI(Storage):
    def __init__(self):
        super().__init__()
        
    def clear(self):
        os.system('cls')
        
    def display_stock(self):
        for ingredient, stock in self.ingredients.items():
            print(f"{ingredient}: {stock} ml/g")
        print()
            
        