from ui import UI
from sys import exit
from time import sleep

class Machine(UI):
    def __init__(self):
        super().__init__()
        
    def run(self):
        self.clear()
        self.display_stock()
        choice = input()