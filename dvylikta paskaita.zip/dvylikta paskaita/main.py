from machine import Machine

if __name__ == "__main__":
    machine = Machine()
    
    while True:
        machine.run()