userInput = int(input("Please enter a number: "))

if(userInput % 2 == 0): print("Number is odd")
else: print('Number is not odd')