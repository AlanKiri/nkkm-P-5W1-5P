names = ['fruits', 'vegs', 'drinks']

names['fruits'] = 1


test_object = {
}

names.append({})


